import React, {Component} from 'react';
import {View, StyleSheet, Text, Image, TextInput, TouchableOpacity, FlatList} from 'react-native';
import { NavigationContainer } from '@react-navigation/native'
import { createBottomTabNavigator } from'@react-navigation/bottom-tabs';



const Tab = createBottomTabNavigator();

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      pedido: [
        {cliente: '', sabor: '', tamanho: '', quantidade: null}
      ]
    }

    this.tabPedidos = this.tabPedidos.bind(this);
    this.tabPizza = this.tabPizza.bind(this);

  }




  tabPizza () {
    return(
      <View style={styles.container}>
        <View style={styles.logo}>
          <Image style={{width: 500, height:200}} source={require ('./src/pizza.jpg')} />
        </View>

        <View style={styles.form}>

            <View style={styles.boxCampos}> 
              <Text style={styles.formTxt}>Cliente:</Text>
              <Text style={styles.formTxt}>Sabor:</Text>
              <Text style={styles.formTxt}>Tamanho:</Text>
              <Text style={styles.formTxt}>Quantidade:</Text>
            </View>

            <View style={styles.boxCampos}> 
              <TextInput style={styles.inputTxt} placeholder={'Ex: Daniel Nascimento'} onChangeText={} />
              <TextInput style={styles.inputTxt} placeholder={'Ex: Calabresa'} onChangeText= {}/>
              <TextInput style={styles.inputTxt} placeholder={'Ex: Broto/Grande'} onChangeText= {}/>
              <TextInput style={styles.inputTxt} placeholder={'Ex: 1'} onChangeText= {}/>
            </View>
        
        </View>

          <TouchableOpacity style={styles.btnForm} onPress={}>
            <Text style={styles.btnTexto}>Gravar Pedido</Text>
          </TouchableOpacity>
        
        
      </View>
    );
  }

  tabPedidos() {
    return(
      <View style={styles.container}>
        <View style={styles.logo}>
          <Image style={{width: 500, height:200}} source={require ('./src/pizza.jpg')} />
        </View>

        <FlatList 
        data = {this.state.pedido}
        renderItem = { ({item}) => <Registros data={item} />}
        keyExtractor={(item) => item.id}
        ></FlatList>

      </View>
    );
  }



  render(){

    return(
      <NavigationContainer>
          <Tab.Navigator>
            <Tab.Screen name="Pizzas" component={this.tabPizza} />
            <Tab.Screen name="Pedidos" component={this.tabPedidos} />
          </Tab.Navigator>
      </NavigationContainer>
    );
  }

}




const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  logo: {
    height:200
  },
  form: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-start'
  },
  formTxt: {
    fontSize: 20,
    marginVertical: 11,
    height: 40
  },
  inputTxt: {
    borderWidth: 1,
    height: 40,
    marginVertical: 10,
    width: 250,
    fontSize: 20,
    padding: 5
  },
  boxCampos: {
    margin: 10,
    flexDirection: 'column'
  },
  btnForm: {
    margin: 90,
    borderWidth: 1,
    padding: 10,
    borderRadius: 5
  },
  btnArea: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    borderTopWidth: 1,
    backgroundColor: '#CFCFCF'
  },
  btn: {
    flex: 1,
    margin: 15,
    borderWidth: 1,
    padding: 10,
    borderRadius: 5
  },
  btnTexto: {
    textAlign: 'center',
    fontSize:15,
    fontWeight: 'bold'
  },
  boxPedido: {
    borderWidth:2,
    margin: 5
  },
  clientePedido: {
    borderBottomWidth:1,
    backgroundColor: '#CFCFCF',
    fontWeight: 'bold',
    fontSize:20,
    padding: 10
  },
  boxPizza: {
    flexDirection: 'row',
    padding: 10
  }

});


class Registros extends Component {
  render() {
    return(
      <View style={styles.boxPedido}>
        <Text style={styles.clientePedido}>Nome do cliente: {this.props.data.cliente}</Text>
        <View style={styles.boxPizza}>
          <Text>{this.props.data.quantidade} - </Text>
          <Text>Pizza de {this.props.data.sabor}</Text>
          <Text> {this.props.data.tamanho}</Text>
        </View>
      </View>
    );
  }
}

export default App;



